require("noise")

local maxSize = 64
love.graphics.setDefaultFilter("nearest")
love.physics.setMeter(32)
local world = love.physics.newWorld(0, 0, true)
local function rect(x, y, w, h, type)
  return love.physics.newFixture(love.physics.newBody(world, x, y, type or "dynamic"), love.physics.newRectangleShape(0, 0, w, h)):getBody()
end
local function circ(x, y, w, h, type)
  local body = love.physics.newBody(world, x, y, type or "dynamic")
  local fixture
  local function reshape(px, py, r)
    if fixture and not fixture:isDestroyed() then fixture:destroy() end
    local shape = love.physics.newCircleShape(px, py, r)
    fixture = love.physics.newFixture(body, shape)
    return fixture, shape
  end
  return reshape, body, reshape(0, 0, math.max(w, h))
end
local levelBounds = 600
local points = {}
for i = 0, math.pi * 2, math.pi * 2 / 30 do
  points[#points + 1] = math.cos(i) * levelBounds
  points[#points + 1] = math.sin(i) * levelBounds
end
love.physics.newFixture(love.physics.newBody(world, x, y, type or "static"), love.physics.newChainShape(true, points)):getBody()
math.randomseed(os.time())
math.random()
math.random()
math.random()

local seeda = math.random(1, 32427)
local agents = {}
local camx, camy, camz = 0, 0, 2
local camSpeed = 500

function agent(seed)
  local p = {}
  local cells, cellids = {}, {}
  local cellImage = love.graphics.newImage(love.image.newImageData(maxSize, maxSize))
  local x, y, z = 0, 0, 0
  local reshape, body, fixture, shape = circ(x, y, 1, 1, "dynamic")
  fixture:setFriction(0)
  body:setUserData(p)
  body:setLinearDamping(5)
  body:setAngularDamping(5)
  body:setAngle(math.random() * math.pi * 2)
  local rot = 0
  local id = math.random(0, 99999999)
  local thread = love.thread.newThread("thread.lua")
  local inputChannel = love.thread.newChannel()
  local outputChannel = love.thread.newChannel()
  local props = {
    seed = seed,
    -- seedp = seed
    seedp = math.random(),
  }
  local age = 0
  table.insert(agents, p)
  local remI = #agents

  thread:start(inputChannel, outputChannel, cellImage, props, body)

  inputChannel:push(cells)

  function p.setXYZ(nx, ny, nz)
    body:setPosition(nx, ny)
    x, y, z = nx, ny, nz or z
  end
  function p.getXYZ() return x, y, z end
  function p.age() return age end

  function p.setCell(x, y, v)
    inputChannel:push({func = "set", x = x, y = y, v = v})
  end

  function p.update(dt)
    if body and not body:isDestroyed() then
      inputChannel:push("think")

      cellImage:refresh()

      age = age + dt

      local info = outputChannel:pop()
      if info then
        local avgX, avgY = info.massX / info.cellCount, info.massY / info.cellCount
        -- assert(avgX == 0)
        reshape(avgX - maxSize * 0.5, avgY - maxSize * 0.5, math.sqrt(info.cellCount) * 0.5)
        -- shape:setPoint(avgX, avgY)
        -- p.renderCells(cells)
        body:setBullet(true)
        body:applyForce(info.forX, info.forY)
        local vx, vy = body:getLinearVelocityFromWorldPoint(0, 0)
        if math.sqrt(vx * vx + vy * vy) < 50 then
          -- body:applyForce(-info.forX, -info.forY)
          -- body:applyTorque(10000 * body:getMass())
        end

        x, y = body:getPosition()
        rot = body:getAngle()

        if age > 0.5 and info.cellCount <= 5 then
          p.remove()
        end
      end

      outputChannel:clear()
    end
  end

  function p.draw()
    love.graphics.draw(cellImage, x, y, rot, 1, 1, cellImage:getWidth() * 0.5, cellImage:getHeight() * 0.5)
    -- love.graphics.draw(cellImage, x, y, rot, 1, 1, cellImage:getWidth() * 0.5, cellImage:getHeight() * 0.5)
  end

  function p.remove()
    inputChannel:push("die")
    thread:wait()
    body:destroy()
    body = nil
    -- thread:kill()
    for _, agent in pairs(agents) do
      if agent == p then
        agents[_] = nil
      end
    end
  end

  return p
end

function love.load()

end

local dragJoint
local hoverAgent

local lastClick
function love.mousepressed(x, y, button)
  local mx, my = love.mouse.getWorldPosition()
  if button == "wu" then
    local dz = camz
    camz = math.min(camz + 0.3, 6)
    dz = (camz - dz) / camz
    camx = camx - (camx - mx) * dz
    camy = camy - (camy - my) * dz
  end
  if button == "wd" then
    local dz = camz
    camz = math.max(camz - 0.3, 0.3)
    dz = (camz - dz) / camz
    camx = camx - (camx - mx) * dz
    camy = camy - (camy - my) * dz
  end
  if button == "l" then
    world:queryBoundingBox(mx - 5, my - 5, mx + 5, my + 5, function(fixture)
      if fixture:testPoint(mx, my) then
        if lastClick and lastClick + 0.2 > love.timer.getTime() then
          fixture:getBody():getUserData().setCell(maxSize * 0.5, maxSize * 0.5, v)
        else
          if dragJoint and not dragJoint:isDestroyed() then
            dragJoint:destroy()
            dragJoint = nil
          end
          dragJoint = love.physics.newMouseJoint(fixture:getBody(), mx, my)
        end
      end
      return true
    end)
    lastClick = love.timer.getTime()
  end
end

function love.mousereleased(x, y, button)
  if button == "l" then
    if dragJoint and not dragJoint:isDestroyed() then
      dragJoint:destroy()
      dragJoint = nil
    end
  end
end

function love.mousemoved(x, y, dx, dy)
  if love.mouse.isDown("r") then
    camx, camy = camx - dx / camz, camy - dy / camz
  end
end

local lastSpawn

function love.update(dt)
  if love.keyboard.isDown("a") then camx = camx - camSpeed * dt / math.min(camz, 1) end
  if love.keyboard.isDown("d") then camx = camx + camSpeed * dt / math.min(camz, 1) end
  if love.keyboard.isDown("w") then camy = camy - camSpeed * dt / math.min(camz, 1) end
  if love.keyboard.isDown("s") then camy = camy + camSpeed * dt / math.min(camz, 1) end

  if dragJoint and not dragJoint:isDestroyed() then
    dragJoint:setTarget(love.mouse.getWorldPosition())
  end

  local n = math.pow(10, 2)
  if (not lastSpawn or lastSpawn + 0 < love.timer.getTime()) and #agents < n then
    lastSpawn = love.timer.getTime()
    local w = math.floor(math.sqrt(n))
    local ww = w * maxSize * 0.25
    local i = #agents
    local ag = agent(math.random() * 4375834)
    -- local ag = agent(seeda + love.math.noise(math.floor(i / 10) / 100) * 25235)
    -- local ag = agent(love.math.noise(seeda + math.floor(i / 10)) * 342)
    -- local x, y = (i % w) * (maxSize * 1) - ww, math.floor(i / w) * (maxSize * 1) - ww
    local a, d = math.random() * math.pi * 2, math.random() * levelBounds * 0.9
    local x, y = math.cos(a) * d, math.sin(a) * d
    ag.setXYZ(x, y)
  end

  world:update(dt)

  hoverAgent = nil
  local mx, my = love.mouse.getWorldPosition()
  world:queryBoundingBox(mx - 5, my - 5, mx + 5, my + 5, function(fixture)
    if fixture:testPoint(mx, my) then
      hoverAgent = fixture:getBody():getUserData()
    end
    return true
  end)

  for _, agent in pairs(agents) do
    agent.update(dt)
  end
end

function love.mouse.getWorldPosition()
  local mx, my = love.mouse.getPosition()
  local sx, sy = love.graphics.getWidth() * 0.5, love.graphics.getHeight() * 0.5
  return (mx - sx) / camz + camx, (my - sy) / camz + camy
end

function love.draw()
  love.graphics.push()
  love.graphics.translate(love.graphics.getWidth() * 0.5, love.graphics.getHeight() * 0.5)
  love.graphics.scale(camz, camz)
  love.graphics.translate(-camx, -camy)

  if hoverAgent then
    love.graphics.setColor(255, 255, 255, 180)
    local dx, dy = hoverAgent.getXYZ()
    love.graphics.setLineWidth(0.1 * camz)
    love.graphics.circle("line", dx, dy, maxSize * 0.6, 100)
    love.graphics.setColor(255, 255, 255, 255)
  end

  love.graphics.setColor(255, 255, 255, 255)
  for _, agent in pairs(agents) do
    agent.draw()
  end

  love.graphics.setColor(255, 255, 255, 255)
  if love.keyboard.isDown("`") then
    love.graphics.point(love.mouse.getWorldPosition())
    for _, body in pairs(world:getBodyList()) do
      if not body:isDestroyed() then
        love.graphics.push()
        love.graphics.translate(body:getPosition())
        love.graphics.rotate(body:getAngle())

        local fixtures = body:getFixtureList()
        for _, fixture in pairs(fixtures) do
          local shape = fixture:getShape()
          if shape.getPoints then
            love.graphics.polygon("line", shape:getPoints())
          else
            love.graphics.translate(shape:getPoint())
            love.graphics.circle("line", 0, 0, shape:getRadius())
          end
        end

        love.graphics.pop()
      end
    end
  end

  love.graphics.pop()

  love.graphics.setColor(255, 255, 255, 255)
end

function love.quit()
  -- for _, agent in pairs(agents) do
  --   agent.remove()
  -- end
  -- agents = nil
end

function love.threaderror(thread, errorstr)
  assert(false, errorstr)
  -- print("Thread error!\n"..errorstr)
  -- thread:getError() will return the same error string now.
end
