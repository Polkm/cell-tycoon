You are going to have to download and install the love 2d package to run the .love file.

There is a PPA for Ubuntu and more information at love2d.org
